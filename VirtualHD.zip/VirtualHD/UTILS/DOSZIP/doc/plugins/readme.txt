Ensure this directory gets created.

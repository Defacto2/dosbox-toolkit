This is a D-Fend Reloaded game package for the game
"debug: no audio, vga gfx".

If you are using D-Fend Reloaded, you can just install this package via
File|Import|Import zip-file or by just dragging the zip file to the
D-Fend Reloaded program window.

If you do not have a D-Fend Reloaded installation on your system, you can
download it here for free:
http://dfendreloaded.sourceforge.net/Download.html

You can also run the game from this package without having D-Fend Reloaded
installed. All you need is DOSBox (http://www.dosbox.com). You can just use
the conf file from this folder to run the game inside DOSBox.

You can find all files needed to run the game in the subfolders of this folder.
